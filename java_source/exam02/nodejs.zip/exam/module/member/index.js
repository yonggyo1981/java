// member/index.js
const odd = 3;

module.exports = odd;